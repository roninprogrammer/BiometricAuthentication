//
//  BiometricAuthentication.h
//  BiometricAuthentication
//
//  Created by roninprogrammer on 07/01/18.
//  Copyright © 2018 roninprogrammer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BiometricAuthentication.
FOUNDATION_EXPORT double BiometricAuthenticationVersionNumber;

//! Project version string for BiometricAuthentication.
FOUNDATION_EXPORT const unsigned char BiometricAuthenticationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BiometricAuthentication/PublicHeader.h>


